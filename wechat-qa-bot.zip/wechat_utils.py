# -*- coding: utf-8 -*-
"""
微信工具函数 - 签名验证和消息解析
"""

import hashlib
import xml.etree.ElementTree as ET


def verify_signature(token, timestamp, nonce, signature):
    """
    验证微信消息签名
    """
    tmp_list = sorted([token, timestamp, nonce])
    tmp_str = ''.join(tmp_list)
    hash_obj = hashlib.sha1(tmp_str.encode('utf-8'))
    expected_signature = hash_obj.hexdigest()
    
    return signature == expected_signature


def parse_xml_message(xml_str):
    """
    解析微信XML消息
    返回字典，包含所有消息字段
    """
    try:
        root = ET.fromstring(xml_str)
        msg_dict = {}
        
        for child in root:
            tag = child.tag
            # 处理CDATA
            if child.text and '<![CDATA[' in ET.tostring(child, encoding='unicode'):
                text = child.text
            else:
                text = child.text or ''
            
            msg_dict[tag] = text.strip()
        
        return msg_dict
    except Exception as e:
        print(f"XML解析错误: {e}")
        return None
