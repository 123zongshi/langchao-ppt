# -*- coding: utf-8 -*-
"""
微信公众号智能问答 - 回复模板

本文件定义回复模板和固定回复内容
"""

HELLO_REPLY = """欢迎来到神码惠普产品查询助手！

我可以帮你查询：
- 产品库存情况（成都/重庆）
- 产品报价（CN2/SRP）
- P/N码对应产品信息

请输入产品名称、系列名或P/N码进行查询，例如：
- 星bookPro14
- fs0021
- BK6H9PA
- 成都库存"""

UNKNOWN_REPLY = """未找到匹配的产品，请尝试：
1. 使用完整的产品型号
2. 使用P/N码查询
3. 使用系列名称查询

常见系列：星book、战66、战X、ENVY等"""

ERROR_REPLY = """查询服务暂时不可用，请稍后再试或联系管理员。"""

def get_help_reply():
    return HELLO_REPLY

def get_unknown_reply(keyword):
    return f"未找到包含「{keyword}」的产品\n\n{UNKNOWN_REPLY}"

def get_error_reply():
    return ERROR_REPLY
