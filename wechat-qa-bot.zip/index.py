# -*- coding: utf-8 -*-
"""
微信公众号智能问答 - 纯Python实现（不依赖Flask）
腾讯云SCF Web函数入口
"""

from http.server import HTTPServer, BaseHTTPRequestHandler
import json
import hashlib
import xml.etree.ElementTree as ET
import os
import time

WECHAT_TOKEN = os.environ.get('WECHAT_TOKEN', 'shangqiu2026')

def verify_signature(token, timestamp, nonce, signature):
    """验证微信签名"""
    tmp_list = sorted([token, timestamp, nonce])
    tmp_str = ''.join(tmp_list)
    hash_obj = hashlib.sha1(tmp_str.encode('utf-8'))
    return hash_obj.hexdigest() == signature

def parse_xml_message(xml_str):
    """解析XML消息"""
    try:
        root = ET.fromstring(xml_str)
        msg_dict = {}
        for child in root:
            msg_dict[child.tag] = child.text.strip() if child.text else ''
        return msg_dict
    except:
        return None

def search_product(keyword):
    """搜索产品"""
    try:
        import openpyxl
        
        excel_path = os.path.join(os.path.dirname(__file__), 'data', 'report.xlsx')
        if not os.path.exists(excel_path):
            return "报表数据暂未更新，请联系管理员"
        
        wb = openpyxl.load_workbook(excel_path, data_only=True)
        results = []
        keyword_lower = keyword.lower()
        
        # 搜索库存及报价 sheet
        if '神码渠道CNB库存及报价' in wb.sheetnames:
            ws = wb['神码渠道CNB库存及报价']
            for i, row in enumerate(ws.iter_rows(values_only=True)):
                if i == 0:
                    continue
                row_text = ' '.join([str(v).lower() for v in row if v is not None])
                if keyword_lower in row_text:
                    series = row[0] if row[0] else ''
                    model = row[1] if len(row) > 1 and row[1] else ''
                    cd_stock = row[2] if len(row) > 2 and row[2] else '无'
                    cq_stock = row[3] if len(row) > 3 and row[3] else '无'
                    pn = row[5] if len(row) > 5 and row[5] else ''
                    cn2 = row[6] if len(row) > 6 and row[6] else ''
                    srp = row[9] if len(row) > 9 and row[9] else ''
                    results.append(f"系列：{series}\n机型：{model}\nP/N：{pn}\n成都库存：{cd_stock}\n重庆库存：{cq_stock}\nCN2：{cn2}\nSRP：{srp}")
        
        # 搜索quotation sheet
        if '4月quotation' in wb.sheetnames:
            ws = wb['4月quotation']
            for i, row in enumerate(ws.iter_rows(values_only=True)):
                if i == 0:
                    continue
                row_text = ' '.join([str(v).lower() for v in row if v is not None])
                if keyword_lower in row_text:
                    series = row[0] if row[0] else ''
                    pn = row[1] if len(row) > 1 and row[1] else ''
                    model = row[2] if len(row) > 2 and row[2] else ''
                    cn2 = row[5] if len(row) > 5 and row[5] else ''
                    srp = row[7] if len(row) > 7 and row[7] else ''
                    results.append(f"系列：{series}\nP/N：{pn}\n型号：{model}\nCN2：{cn2}\nSRP：{srp}")
        
        if not results:
            return f"未找到包含「{keyword}」的产品"
        
        return f"找到 {len(results)} 条结果：\n\n" + "\n\n".join(results[:5])
        
    except Exception as e:
        return f"查询出错: {str(e)}"

def build_text_reply(to_user, from_user, content):
    """构建文本回复XML"""
    return f"""<xml>
<ToUserName><![CDATA[{to_user}]]></ToUserName>
<FromUserName><![CDATA[{from_user}]]></FromUserName>
<CreateTime>{int(time.time())}</CreateTime>
<MsgType><![CDATA[text]]></MsgType>
<Content><![CDATA[{content}]]></Content>
</xml>"""

class WeChatHandler(BaseHTTPRequestHandler):
    """处理微信请求"""
    
    def do_GET(self):
        """微信URL验证"""
        signature = self.headers.get('X-Wechat-Signature', '')
        timestamp = self.headers.get('X-Wechat-Timestamp', '')
        nonce = self.headers.get('X-Wechat-Nonce', '')
        
        # 从query string获取参数
        from urllib.parse import urlparse, parse_qs
        parsed = urlparse(self.path)
        params = parse_qs(parsed.query)
        
        signature = params.get('signature', [''])[0]
        timestamp = params.get('timestamp', [''])[0]
        nonce = params.get('nonce', [''])[0]
        echostr = params.get('echostr', [''])[0]
        
        if verify_signature(WECHAT_TOKEN, timestamp, nonce, signature):
            self.send_response(200)
            self.send_header('Content-Type', 'text/plain')
            self.end_headers()
            self.wfile.write(echostr.encode())
        else:
            self.send_response(403)
            self.end_headers()
    
    def do_POST(self):
        """处理用户消息"""
        content_length = int(self.headers.get('Content-Length', 0))
        post_data = self.rfile.read(content_length).decode('utf-8')
        
        msg_dict = parse_xml_message(post_data)
        if not msg_dict:
            self.send_response(200)
            self.end_headers()
            return
        
        msg_type = msg_dict.get('MsgType', 'text')
        from_user = msg_dict.get('FromUserName', '')
        to_user = msg_dict.get('ToUserName', '')
        content = msg_dict.get('Content', '').strip()
        
        if msg_type == 'text':
            reply = search_product(content) if content else "请输入产品名称查询"
        else:
            reply = "暂不支持此类消息类型"
        
        response = build_text_reply(from_user, to_user, reply)
        
        self.send_response(200)
        self.send_header('Content-Type', 'application/xml')
        self.end_headers()
        self.wfile.write(response.encode())
    
    def log_message(self, format, *args):
        """抑制日志输出"""
        pass

def application(environ, start_response):
    """WSGI应用入口"""
    port = int(os.environ.get('PORT', 9000))
    
    # 使用内置HTTP服务器处理请求
    # 这个函数在SCF中由外部网关调用
    pass

# 导出handler供SCF使用
handler = WeChatHandler
