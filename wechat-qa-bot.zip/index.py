# -*- coding: utf-8 -*-
"""
Flask App - 腾讯云SCF Web函数
"""

from flask import Flask, request, Response
import time
import os

app = Flask(__name__)

WECHAT_TOKEN = os.environ.get('WECHAT_TOKEN', 'shangqiu2026')


@app.route('/', methods=['GET', 'POST'])
def wechat():
    """微信接入验证和消息处理（根路径）"""
    
    # GET 请求 - 微信URL验证
    if request.method == 'GET':
        signature = request.args.get('signature', '')
        timestamp = request.args.get('timestamp', '')
        nonce = request.args.get('nonce', '')
        echostr = request.args.get('echostr', '')
        
        # 验证签名
        import hashlib
        tmp_list = sorted([WECHAT_TOKEN, timestamp, nonce])
        tmp_str = ''.join(tmp_list)
        hash_obj = hashlib.sha1(tmp_str.encode('utf-8'))
        expected_signature = hash_obj.hexdigest()
        
        if signature == expected_signature:
            return echostr
        else:
            return 'Signature verification failed', 403
    
    # POST 请求 - 处理用户消息
    else:
        from wechat_utils import parse_xml_message
        from excel_search import search_product
        
        xml_data = request.data.decode('utf-8')
        msg_dict = parse_xml_message(xml_data)
        
        if not msg_dict:
            return '', 200
        
        msg_type = msg_dict.get('MsgType', 'text')
        from_user = msg_dict.get('FromUserName', '')
        to_user = msg_dict.get('ToUserName', '')
        content = msg_dict.get('Content', '').strip()
        
        # 处理文本消息
        if msg_type == 'text':
            reply = process_user_query(content)
        else:
            reply = "暂不支持此类消息类型，请发送产品名称或P/N码查询"
        
        # 构建回复XML
        response = build_text_reply(from_user, to_user, reply)
        
        return Response(response, mimetype='application/xml')


@app.route('/test')
def test():
    """测试路由"""
    return 'WeChat QA Bot is running!'


def process_user_query(query):
    """处理用户查询"""
    if not query:
        return "请输入要查询的产品名称、P/N码或系列名称，例如：\n- 星bookPro14\n- fs0021\n- BK6H9PA\n- 成都库存"
    
    result = search_product(query)
    return result


def build_text_reply(to_user, from_user, content):
    """构建文本回复XML"""
    xml = f"""<xml>
<ToUserName><![CDATA[{to_user}]]></ToUserName>
<FromUserName><![CDATA[{from_user}]]></FromUserName>
<CreateTime>{int(time.time())}</CreateTime>
<MsgType><![CDATA[text]]></MsgType>
<Content><![CDATA[{content}]]></Content>
</xml>"""
    return xml


# 导出app对象供SCF Web函数调用
application = app
