# -*- coding: utf-8 -*-
"""
微信公众号智能问答 - Flask Web应用
腾讯云SCF Web函数入口
"""

import os
import time
from flask import Flask, request, Response
from wechat_utils import verify_signature, parse_xml_message
from excel_search import search_product

app = Flask(__name__)

# 配置
WECHAT_TOKEN = os.environ.get('WECHAT_TOKEN', 'shangqiu2026')


@app.route('/', methods=['GET', 'POST'])
def wechat_handler():
    """
    微信接入验证和消息处理
    """
    # GET 请求 - 微信URL验证
    if request.method == 'GET':
        signature = request.args.get('signature', '')
        timestamp = request.args.get('timestamp', '')
        nonce = request.args.get('nonce', '')
        echostr = request.args.get('echostr', '')
        
        if verify_signature(WECHAT_TOKEN, timestamp, nonce, signature):
            return echostr
        else:
            return 'Signature verification failed', 403
    
    # POST 请求 - 处理用户消息
    else:
        xml_data = request.data.decode('utf-8')
        msg_dict = parse_xml_message(xml_data)
        
        if not msg_dict:
            return '', 200
        
        msg_type = msg_dict.get('MsgType', 'text')
        from_user = msg_dict.get('FromUserName', '')
        to_user = msg_dict.get('ToUserName', '')
        content = msg_dict.get('Content', '').strip()
        
        # 处理文本消息
        if msg_type == 'text':
            reply = process_user_query(content)
        else:
            reply = "暂不支持此类消息类型，请发送产品名称或P/N码查询"
        
        # 构建回复XML
        response = build_text_reply(from_user, to_user, reply)
        
        return Response(response, mimetype='application/xml')


def process_user_query(query):
    """
    处理用户查询
    """
    if not query:
        return "请输入要查询的产品名称、P/N码或系列名称，例如：\n- 星bookPro14\n- fs0021\n- BK6H9PA\n- 成都库存"
    
    result = search_product(query)
    return result


def build_text_reply(to_user, from_user, content):
    """
    构建文本回复XML
    """
    xml = f"""<xml>
<ToUserName><![CDATA[{to_user}]]></ToUserName>
<FromUserName><![CDATA[{from_user}]]></FromUserName>
<CreateTime>{int(time.time())}</CreateTime>
<MsgType><![CDATA[text]]></MsgType>
<Content><![CDATA[{content}]]></Content>
</xml>"""
    return xml


# 腾讯云SCF Web函数入口
def main_handler(event, context):
    """
    腾讯云SCF Web函数入口
    注意：腾讯云SCF Web函数会自动调用Flask app，不需要这个handler
    这里保留是为了兼容事件函数的调用方式
    """
    return app(event, context)
