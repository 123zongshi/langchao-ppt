# -*- coding: utf-8 -*-
"""
Excel 报表搜索逻辑
根据用户查询词搜索库存和报价数据
"""

import os
import json

# Excel文件路径
EXCEL_PATH = '/tmp/report.xlsx'
LOCAL_EXCEL_PATH = os.path.join(os.path.dirname(__file__), 'data', 'report.xlsx')


def get_excel_path():
    """
    获取Excel文件路径
    云函数环境优先使用 /tmp，本地调试使用相对路径
    """
    if os.path.exists(EXCEL_PATH):
        return EXCEL_PATH
    elif os.path.exists(LOCAL_EXCEL_PATH):
        return LOCAL_EXCEL_PATH
    else:
        return None


def search_product(keyword):
    """
    根据关键词搜索产品
    支持：机型名、P/N码、系列名
    """
    import openpyxl
    
    excel_path = get_excel_path()
    if not excel_path:
        return "报表数据暂未更新，请联系管理员"
    
    try:
        wb = openpyxl.load_workbook(excel_path, data_only=True)
        
        results = []
        
        # 搜索库存及报价 sheet
        if '神码渠道CNB库存及报价' in wb.sheetnames:
            ws = wb['神码渠道CNB库存及报价']
            results.extend(search_inventory_sheet(ws, keyword))
        
        # 搜索quotation sheet
        if '4月quotation' in wb.sheetnames:
            ws = wb['4月quotation']
            results.extend(search_quotation_sheet(ws, keyword))
        
        # 搜索线上产品 sheet
        if '神码线上产品' in wb.sheetnames:
            ws = wb['神码线上产品']
            results.extend(search_online_sheet(ws, keyword))
        
        if not results:
            return f"未找到包含「{keyword}」的产品，请尝试其他关键词"
        
        # 格式化输出
        return format_results(results)
        
    except Exception as e:
        return f"查询出错: {str(e)}"


def search_inventory_sheet(ws, keyword):
    """
    搜索 神码渠道CNB库存及报价 sheet
    """
    results = []
    keyword_lower = keyword.lower()
    
    for i, row in enumerate(ws.iter_rows(values_only=True)):
        # 跳过表头
        if i == 0:
            continue
        
        row_text = ' '.join([str(v).lower() for v in row if v is not None])
        
        if keyword_lower in row_text:
            series = row[0] if row[0] else ''
            model = row[1] if len(row) > 1 and row[1] else ''
            cd_stock = row[2] if len(row) > 2 and row[2] else '无'
            cq_stock = row[3] if len(row) > 3 and row[3] else '无'
            wq_source = row[4] if len(row) > 4 and row[4] else ''
            pn = row[5] if len(row) > 5 and row[5] else ''
            cn2 = row[6] if len(row) > 6 and row[6] else ''
            discount = row[7] if len(row) > 7 and row[7] else ''
            srp = row[9] if len(row) > 9 and row[9] else ''
            config = row[10] if len(row) > 10 and row[10] else ''
            
            results.append({
                'type': '库存及报价',
                'series': str(series) if series else '',
                'model': str(model) if model else '',
                'cd_stock': cd_stock,
                'cq_stock': cq_stock,
                'wq_source': str(wq_source) if wq_source else '',
                'pn': str(pn) if pn else '',
                'cn2': str(cn2) if cn2 else '',
                'discount': str(discount) if discount else '',
                'srp': str(srp) if srp else '',
                'config': str(config) if config else ''
            })
    
    return results


def search_quotation_sheet(ws, keyword):
    """
    搜索 4月quotation sheet
    """
    results = []
    keyword_lower = keyword.lower()
    
    for i, row in enumerate(ws.iter_rows(values_only=True)):
        if i == 0:
            continue
        
        row_text = ' '.join([str(v).lower() for v in row if v is not None])
        
        if keyword_lower in row_text:
            series = row[0] if row[0] else ''
            pn = row[1] if len(row) > 1 and row[1] else ''
            model = row[2] if len(row) > 2 and row[2] else ''
            new_cn2 = row[3] if len(row) > 3 and row[3] else ''
            old_cn2 = row[4] if len(row) > 4 and row[4] else ''
            apr_cn2 = row[5] if len(row) > 5 and row[5] else ''
            srp = row[7] if len(row) > 7 and row[7] else ''
            config = row[8] if len(row) > 8 and row[8] else ''
            
            results.append({
                'type': '4月报价',
                'series': str(series) if series else '',
                'pn': str(pn) if pn else '',
                'model': str(model) if model else '',
                'new_cn2': str(new_cn2) if new_cn2 else '',
                'old_cn2': str(old_cn2) if old_cn2 else '',
                'apr_cn2': str(apr_cn2) if apr_cn2 else '',
                'srp': str(srp) if srp else '',
                'config': str(config) if config else ''
            })
    
    return results


def search_online_sheet(ws, keyword):
    """
    搜索 神码线上产品 sheet
    """
    results = []
    keyword_lower = keyword.lower()
    
    for i, row in enumerate(ws.iter_rows(values_only=True)):
        if i == 0:
            continue
        
        row_text = ' '.join([str(v).lower() for v in row if v is not None])
        
        if keyword_lower in row_text:
            desc = row[2] if len(row) > 2 and row[2] else ''
            cn2 = row[3] if len(row) > 3 and row[3] else ''
            policy = row[4] if len(row) > 4 and row[4] else ''
            price = row[5] if len(row) > 5 and row[5] else ''
            stock = row[6] if len(row) > 6 and row[6] else ''
            
            results.append({
                'type': '线上产品',
                'desc': str(desc) if desc else '',
                'cn2': str(cn2) if cn2 else '',
                'policy': str(policy) if policy else '',
                'price': str(price) if price else '',
                'stock': str(stock) if stock else ''
            })
    
    return results


def format_results(results):
    """
    格式化搜索结果为微信回复文本
    """
    if not results:
        return "未找到相关产品"
    
    lines = []
    lines.append(f"找到 {len(results)} 条相关结果：\n")
    
    for i, r in enumerate(results[:5], 1):  # 最多显示5条
        lines.append(f"--- 结果 {i} ---")
        
        if r.get('type') == '库存及报价':
            lines.append(f"系列：{r['series']}")
            lines.append(f"机型：{r['model']}")
            lines.append(f"P/N：{r['pn']}")
            lines.append(f"成都库存：{r['cd_stock']}")
            lines.append(f"重庆库存：{r['cq_stock']}")
            if r['wq_source']:
                lines.append(f"外区货源：{r['wq_source']}")
            lines.append(f"4月CN2：{r['cn2']}")
            if r['srp']:
                lines.append(f"SRP价格：{r['srp']}")
            if r['config']:
                lines.append(f"配置：{r['config'][:50]}...")
        
        elif r.get('type') == '4月报价':
            lines.append(f"系列：{r['series']}")
            lines.append(f"P/N：{r['pn']}")
            lines.append(f"型号：{r['model']}")
            lines.append(f"4月CN2：{r['apr_cn2']}")
            if r['srp']:
                lines.append(f"点杀SRP：{r['srp']}")
            if r['config']:
                lines.append(f"配置：{r['config'][:50]}...")
        
        elif r.get('type') == '线上产品':
            lines.append(f"产品：{r['desc']}")
            lines.append(f"CN2：{r['cn2']}")
            lines.append(f"政策：{r['policy']}")
            lines.append(f"库存：{r['stock']}")
        
        lines.append("")
    
    if len(results) > 5:
        lines.append(f"（还有 {len(results) - 5} 条结果，请更精确描述）")
    
    return '\n'.join(lines)
