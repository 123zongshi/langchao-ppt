@echo off
chcp 65001 >nul
echo ========================================
echo  微信公众号智能问答云函数 - 部署脚本
echo ========================================
echo.

echo [1/5] 检查腾讯云 CLI 环境...
where scf >nul 2>&1
if errorlevel 1 (
    echo   错误：未找到 scf 命令
    echo   请先安装腾讯云 CLI：npm install -g @cloudbase/cli
    echo   或参考：https://cloud.tencent.com/document/product/583/40461
    pause
    exit /b 1
)
echo   OK

echo.
echo [2/5] 检查 Python 依赖...
where python >nul 2>&1
if errorlevel 1 (
    echo   错误：未找到 Python
    pause
    exit /b 1
)
echo   OK

echo.
echo [3/5] 创建部署包...
mkdir temp_deploy 2>nul
copy index.py temp_deploy\
copy wechat_utils.py temp_deploy\
copy excel_search.py temp_deploy\
copy reply_templates.py temp_deploy\
copy requirements.txt temp_deploy\
echo   OK

echo.
echo [4/5] 打包...
cd temp_deploy
powershell -Command "Compress-Archive -Path * -DestinationPath ..\deploy_package.zip -Force"
cd ..
echo   OK

echo.
echo [5/5] 部署到腾讯云...
echo   请确保已运行：scf configure set --region ap-guangzhou --secretId YOUR_ID --secretKey YOUR_KEY
echo.
scf deploy --function-name wechat-qa-bot --runtime Python3.9 --zip-file deploy_package.zip --handler index.main_handler --description "微信公众号智能问答"
echo.
echo ========================================
echo  部署完成！
echo ========================================
echo.
echo 下一步：
echo 1. 在腾讯云 SCF 控制台配置环境变量 WECHAT_TOKEN
echo 2. 在公众号后台配置服务器地址为云函数触发URL
echo.

pause
