# 微信公众号智能问答云函数

## 项目结构

```
wechat-qa-bot/
├── index.py              # 云函数入口
├── wechat_utils.py       # 微信签名验证
├── excel_search.py       # Excel 搜索逻辑
├── reply_templates.py    # 回复模板
├── data/
│   └── report.xlsx       # 报表数据（我每次更新）
├── requirements.txt      # 依赖
└── deploy.sh             # 部署脚本
```

## 功能说明

- 接收用户发来的消息
- 根据机型名称/P/N码/系列搜索库存和报价
- 回复格式化的查询结果
