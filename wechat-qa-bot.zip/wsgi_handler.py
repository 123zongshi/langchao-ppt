# -*- coding: utf-8 -*-
"""
Web函数 WSGI 入口 - 适配腾讯云SCF Web函数
"""

from index import app
from werkzeug.serving import run_simple

if __name__ == '__main__':
    # 本地开发测试用
    run_simple('0.0.0.0', 9000, app, use_debugger=True, use_reloader=True)
else:
    # 腾讯云SCF环境 - 不使用内置服务器
    application = app
